package com.result.management.utility;

public class Constants {

	public static final String ALREADY = "ALREADY";
	public static final String SUCCESS ="SUCCESS";
	public static final String PASS = "PASS";
	public static final String FAIL ="FAIL";

}
